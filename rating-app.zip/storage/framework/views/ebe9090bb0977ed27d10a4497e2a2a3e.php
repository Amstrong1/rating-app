<textarea
    <?php echo e($attributes->merge([
        'class' => implode(' ', [
        $errors->has($name) ? 'form-input is-invalid block w-full placeholder:italic' : 'form-input block w-full placeholder:italic'
        ]),
    ])); ?> rows=5><?php echo e($slot); ?></textarea>
<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/components/inputs/textarea.blade.php ENDPATH**/ ?>