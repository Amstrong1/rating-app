<input <?php echo $attributes->merge([
    'class' => implode(' ', [
        $errors->has($name) ? 'form-input is-invalid block w-full placeholder:text-sm' : 'form-input block w-full placeholder:text-sm'
    ]), 
]); ?>>
<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/components/inputs/text.blade.php ENDPATH**/ ?>