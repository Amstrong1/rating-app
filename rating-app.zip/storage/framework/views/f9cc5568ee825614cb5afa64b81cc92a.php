<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id','name','class']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id','name','class']); ?>
<?php foreach (array_filter((['id','name','class']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginalde97bed94da55ab562b6775e3f3a83f9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalde97bed94da55ab562b6775e3f3a83f9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.multiple-select','data' => ['id' => $id,'name' => $name,'class' => $class]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.multiple-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalde97bed94da55ab562b6775e3f3a83f9)): ?>
<?php $attributes = $__attributesOriginalde97bed94da55ab562b6775e3f3a83f9; ?>
<?php unset($__attributesOriginalde97bed94da55ab562b6775e3f3a83f9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalde97bed94da55ab562b6775e3f3a83f9)): ?>
<?php $component = $__componentOriginalde97bed94da55ab562b6775e3f3a83f9; ?>
<?php unset($__componentOriginalde97bed94da55ab562b6775e3f3a83f9); ?>
<?php endif; ?><?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\storage\framework\views/828710cddb5087b75e50f1ccecf938ef.blade.php ENDPATH**/ ?>