

<select <?php echo e($attributes->merge(['class'=>"simple-select form-input"])); ?>>
    <?php echo e($slot); ?>

</select><?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/components/inputs/model.blade.php ENDPATH**/ ?>