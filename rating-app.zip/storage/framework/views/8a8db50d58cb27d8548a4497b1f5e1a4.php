<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>