

<img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" alt="logo" srcset=""><?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>