<div class="mx-auto py-6 px-4 lg:px-8 hidden lg:block">
    <nav class="relative flex w-full items-center justify-between lg:justify-center py-2 text-neutral-600 dark:text-neutral-300 lg:flex-wrap"
        data-te-navbar-ref>
        <div class="px-2">
            <div class="flex-grow basis-[100%] items-center lg:flex lg:basis-auto text-white"
                id="navbarSupportedContentX" data-te-collapse-item>
                <?php if(Auth::user()->role === 'superadmin'): ?>
                    <?php echo $__env->make('layouts.partials.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(Auth::user()->role === 'admin'): ?>
                    <?php echo $__env->make('layouts.partials.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>