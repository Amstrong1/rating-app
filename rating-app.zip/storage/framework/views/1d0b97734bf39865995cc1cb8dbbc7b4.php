<input <?php echo $attributes->merge([
    'class' => 'block w-full text-sm text-slate-500
file:mr-4 file:py-2 file:px-4
file:rounded-lg file:border-0
file:text-sm file:font-semibold
file:bg-violet-50 file:text-main
hover:file:bg-violet-100 focus:border-main focus:ring focus:ring-main focus:ring-opacity-50  dark:text-gray-300 dark:focus:shadow-outline-gray
  ',
    'type' => 'file',
]); ?>>


<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/components/inputs/file.blade.php ENDPATH**/ ?>