<?php if(Auth::user()->role === 'superadmin'): ?>
    <?php echo $__env->make('layouts.partials.mobile.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Auth::user()->role === 'admin'): ?>
    <?php echo $__env->make('layouts.partials.mobile.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<script src="https://unpkg.com/@popperjs/core@2.9.1/dist/umd/popper.min.js" charset="utf-8"></script>
<script>
    function openDropdown(event, dropdownID) {
        // let dropups = document.getElementsByClassName('dropup');
        let element = event.target;
        while (element.nodeName !== "BUTTON") {
            element = element.parentNode;
        }
        var popper = Popper.createPopper(element, document.getElementById(dropdownID), {
            placement: 'top-end'
        });
        document.getElementById(dropdownID).classList.toggle("hidden");
        document.getElementById(dropdownID).classList.toggle("block");
    }
</script>
<?php /**PATH D:\project_vibecro_corp\rating_app\rating-app\resources\views/layouts/navigation-bottom.blade.php ENDPATH**/ ?>