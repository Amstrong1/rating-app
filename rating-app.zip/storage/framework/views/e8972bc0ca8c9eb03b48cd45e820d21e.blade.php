<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['id','name','type','class'])
<x-inputs.textarea :id="$id" :name="$name" :type="$type" :class="$class" >

{{ $slot ?? "" }}
</x-inputs.textarea>