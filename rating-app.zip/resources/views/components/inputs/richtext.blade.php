<textarea {{$attributes->merge(['class'=>'
    mt-1 rounded-md border-gray-300 shadow-sm focus:border-main focus:ring focus:ring-[#2b58a4] focus:ring-opacity-50 text-sm dark:text-gray-300 
    dark:border-gray-600 dark:bg-gray-700 focus:border-main focus:outline-none dark:focus:shadow-outline-gray text-lg'])}} >
    {{$slot}}
</textarea>