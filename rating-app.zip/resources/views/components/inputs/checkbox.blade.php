<input type="checkbox"
    {{ $attributes->merge(['class' => 'rounded border-gray-300 text-main shadow-sm focus:border-main focus:ring-2 focus:ring-main focus:ring-opacity-50']) }}>
