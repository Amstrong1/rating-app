<select {{$attributes->merge(['class'=>"form-input simple-select"])}}>
    {{$slot}}
</select>