<select {{$attributes->merge(['class'=>"simple-select form-input"])}}>
  {{$slot}}
</select>